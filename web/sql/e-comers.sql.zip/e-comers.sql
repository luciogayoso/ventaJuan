--
-- Base de datos: `e-comers`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito`
--

CREATE TABLE `carrito` (
  `id_carrito` int(4) NOT NULL,
  `id_usuario` int(4) NOT NULL,
  `id_producto` int(50) NOT NULL,
  `c_talle` varchar(10) DEFAULT NULL,
  `c_cantidad` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `carrito`
--

INSERT INTO `carrito` (`id_carrito`, `id_usuario`, `id_producto`, `c_talle`, `c_cantidad`) VALUES
(19, 1, 22, 'M', '1'),
(21, 1, 19, 'L', '1'),
(22, 1, 21, 'L', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `otroscolores`
--

CREATE TABLE `otroscolores` (
  `id_otrosColores` int(4) NOT NULL,
  `id_producto` int(4) NOT NULL,
  `o_img` varchar(50) NOT NULL,
  `o_color` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `otroscolores`
--

INSERT INTO `otroscolores` (`id_otrosColores`, `id_producto`, `o_img`, `o_color`) VALUES
(2, 19, 'DSC_0702.JPG', '#000080'),
(3, 19, 'DSC_0701.JPG', 'null');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id_producto` int(4) NOT NULL,
  `p_codigo` varchar(50) DEFAULT NULL,
  `p_nombre` varchar(70) NOT NULL,
  `p_precio` int(30) DEFAULT NULL,
  `p_img` varchar(100) NOT NULL,
  `p_img_b` varchar(100) NOT NULL,
  `p_estado` varchar(70) DEFAULT NULL,
  `p_stock` int(40) NOT NULL,
  `id_carrito` int(4) DEFAULT NULL,
  `p_color` varchar(50) NOT NULL,
  `p_tipo` varchar(70) DEFAULT NULL,
  `p_talleS` int(20) NOT NULL,
  `p_talleM` int(20) NOT NULL,
  `p_talleL` int(20) NOT NULL,
  `p_talleXL` int(20) NOT NULL,
  `p_despcripcion` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `p_codigo`, `p_nombre`, `p_precio`, `p_img`, `p_img_b`, `p_estado`, `p_stock`, `id_carrito`, `p_color`, `p_tipo`, `p_talleS`, `p_talleM`, `p_talleL`, `p_talleXL`, `p_despcripcion`) VALUES
(19, 'fkfjdks', 'Vestido rayas bordo', 1190, 'DSC_0668.JPG', 'DSC_0668@.JPG', NULL, 500, NULL, '#d52b2b', 'Vestido', 200, 150, 100, 50, 'Vestido a rayas con diversos colores'),
(21, 'fkfjdks', 'vestido Julieta modal premium', 990, 'DSC_0806.JPG', 'DSC_0806@.JPG', NULL, 200, NULL, '#000000', 'Vestido', 100, 50, 20, 30, 'Vestido Premiun'),
(22, 'fkfjdks', 'vestido lanilla', 1190, 'DSC_0639.JPG', 'DSC_0639@.JPG', NULL, 300, NULL, '#c0c0c0', 'Vestido', 200, 50, 20, 30, 'vestido con diseÃ±o unico'),
(23, 'fkfjdks', 'Blusa tul bordado natura', 990, 'DSC_0884.JPG', 'DSC_0884@.JPG', NULL, 300, NULL, '#ffffff', 'Blusas', 200, 50, 50, 0, 'hay varios motivos'),
(24, 'fkfjdks', 'Sweater blanco hilo bordado', 990, 'DSC_0878.JPG', 'DSC_0878@.JPG', NULL, 323, NULL, '#ffffff', 'Blusas', 200, 23, 100, 0, 'fdnjskjafkldjaslk');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `u_id` int(4) NOT NULL,
  `u_nombre` varchar(50) NOT NULL,
  `u_apellido` varchar(50) NOT NULL,
  `u_mail` varchar(60) NOT NULL,
  `u_nombreUsuario` varchar(60) NOT NULL,
  `u_clave` varchar(40) NOT NULL,
  `u_tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`u_id`, `u_nombre`, `u_apellido`, `u_mail`, `u_nombreUsuario`, `u_clave`, `u_tipo`) VALUES
(1, 'Lucio', 'Gayoso', 'luciogayoso@gmail.com', 'lucio', '1234', 'cliente'),
(2, 'vita', 'fjdskla', 'fdjsakl', 'jfdskla', 'fdjsal', 'cliente'),
(4, 'fjdskjafklad', 'JFDJJKFJA', 'FJDAKLSJA', 'JFDSKLAJFA', 'FJDSKLAJ', 'cliente'),
(5, 'vity', 'Gayoso', 'vityfjdskl@gjmd.com', 'vity', '1234', 'cliente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`id_carrito`);

--
-- Indices de la tabla `otroscolores`
--
ALTER TABLE `otroscolores`
  ADD PRIMARY KEY (`id_otrosColores`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carrito`
--
ALTER TABLE `carrito`
  MODIFY `id_carrito` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de la tabla `otroscolores`
--
ALTER TABLE `otroscolores`
  MODIFY `id_otrosColores` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id_producto` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `u_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
